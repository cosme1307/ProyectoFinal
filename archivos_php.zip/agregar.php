<?php
$titulo = $_REQUEST["titulo"];
$autor = $_REQUEST["autor"];
$letra = $_REQUEST["letra"];

$con = mysqli_connect("localhost","id11616934_proyectofinalsis22","12345678","id11616934_himnario") or die ("Sin Conexion");

$sql = "INSERT INTO alabanza (titulo, autor, letra ) VALUES ('$titulo', '$autor', '$letra')";

$resul = mysqli_query($con, $sql);

echo $resul;

mysqli_close($con);
?>