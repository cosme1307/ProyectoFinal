<?php
$id = $_REQUEST["id"];
$con = mysqli_connect("localhost","id11616934_proyectofinalsis22","12345678","id11616934_himnario") or die ("Sin Conexion");
$sql = "delete from corosAle where id=$id";
if(mysqli_query($con,$sql)){
    echo "Alabanza eliminada exitosamente";
}else{
    echo "Error: " . mysqli_error($con);
}
mysqli_close($con);
?>