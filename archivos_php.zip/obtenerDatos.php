<?php
$con = mysqli_connect("localhost","id11616934_proyectofinalsis22","12345678","id11616934_himnario") or die ("Sin Conexion");
$sql = "select * from alabanza";
$datos = Array();
$resul = mysqli_query($con,$sql);

while($row = mysqli_fetch_object($resul)){
    $datos[] = $row;
}

echo json_encode($datos);
mysqli_close($con);
?>